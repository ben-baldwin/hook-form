import React, { useState } from 'react';

const Form = (props) => {
    const [firstName, setfirstName] = useState("");
    const [lastName, setlastName] = useState("");
    const [email, setemail] = useState("");
    const [password, setpassword] = useState("");
    const [confirmPassword, setconfirmPassword] = useState("");

    const createUser = (e) => {
        // prevents page from refreshing everytime
        e.preventDefault();
        const newUser = { firstName, lastName, email, password };
        console.log("Welcome, newUser");
    };

    return (
        <form onSubmit={createUser}>
            <div>
                <label>First name: </label>
                {/* I dont understand line 22 fully. SOS */}
                <input type="text" value={firstName} onChange = {(e) => setfirstName(e.target.value)} />
            </div>
            <div>
                <label>Last name: </label>
                <input type="text" value={lastName} onChange = {(e) => setlastName(e.target.value)} />
            </div>
            <div>
                <label>Email: </label>
                <input type="email" value={email} onChange = {(e) => setemail(e.target.value)} />
            </div>
            <div>
                <label>Password: </label>
                <input type="password" value={password} onChange = {(e) => setpassword(e.target.value)} />
            </div>
            <div>
                <label>Confirm Password: </label>
                <input type="password" value={confirmPassword} onChange = {(e) => setconfirmPassword(e.target.value)} />
            </div>
            <input type="submit"/>
            <p>*Your Form Data*</p>
            <p>First Name: {firstName}</p>
            <p>Last Name: {lastName}</p>
            <p>Email: {email}</p>
            <p>Password: {password}</p>
            <p>Confirm Password: {confirmPassword}</p>
        </form>
    );
};

export default Form;